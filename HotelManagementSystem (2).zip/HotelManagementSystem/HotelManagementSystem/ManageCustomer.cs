﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace HotelManagementSystem
{
    public partial class ManageCustomer : Form
    {
        Customer c1=new Customer();
        public ManageCustomer()
        {
            InitializeComponent();
        }

        private void ManageCustomer_Load(object sender, EventArgs e)
        {
           
            
        }

        private void CAddNew_Click(object sender, EventArgs e)
        {
            string dbconn = Customer.dbcon();
           MySqlConnection con = new MySqlConnection(dbconn);
          //  con.Open();
         //   if (con.State == ConnectionState.Open)
          //  {
          //      MessageBox.Show("Database Connected");
          // }
         //   else
         //  {
         //       MessageBox.Show("Database not Connected");
        //    }

            string query = "insert into hms.customer(id,name,cnic,email,gender,age,phone,address) VALUES('" + c1.hid + "','" + c1.name + "','" + c1.cnic + "','" + c1.email + "','" + c1.gender + "','" + c1.age + "','" + c1.phone + "','" + c1.address + "');";
          con.Open();
            MySqlCommand comm = new MySqlCommand(query, con);
            if (comm.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Data Inserted");
            }
            else
            {
                MessageBox.Show("Not Inserted");
            }
            con.Close();


          //  txtBoxCId.Text = "";
         //   textBoxName.Text = "";
          //  textBoxCNIC.Text = "";
           // textBoxEmailId.Text = "";
           // comboBoxGender.Text = "";
          //  textBoxAge.Text = "";
          //  textBoxCPhone.Text = "";
          //  textBoxCAddress.Text = "";
             
        }

        private void txtBoxCId_TextChanged(object sender, EventArgs e)
        {
            c1.hid = txtBoxCId.Text;
        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            c1.name = textBoxName.Text;
        }

        private void textBoxCNIC_TextChanged(object sender, EventArgs e)
        {
            c1.cnic = textBoxCNIC.Text;
        }

        private void textBoxEmailId_TextChanged(object sender, EventArgs e)
        {
            c1.email = textBoxEmailId.Text;
        }

        private void comboBoxGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            c1.gender = comboBoxGender.Text;
        }

        private void textBoxAge_TextChanged(object sender, EventArgs e)
        {
            c1.age = int.Parse(textBoxAge.Text);
        }

        private void textBoxCPhone_TextChanged(object sender, EventArgs e)
        {
            c1.phone = textBoxCPhone.Text;
        }

        private void textBoxCAddress_TextChanged(object sender, EventArgs e)
        {
            c1.address = textBoxCAddress.Text;
        }
    }
}
