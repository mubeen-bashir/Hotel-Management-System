﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Human
    {
        protected string hID;
        public string hid
        { set { hID = value; } get { return hID; } }

        protected string Name;
        public string name
        { set { Name = value; } get { return Name; } }

        protected string Gender;
        public string gender
        { set { Gender = value; } get { return Gender; } }

        protected string Phone;
        public string phone
        { set { Phone = value; } get { return Phone; } }

        protected string Address;
        public string address
        { set { Address = value; } get { return Address; } }

        protected int Age;
        public int age
        { set { Age = value; } get { return Age; } }

        protected string Email;
        public string email { set { Email = value; } get { return Email; } }

        protected string Cnic;
        public string cnic
        { set { Cnic = value; } get { return Cnic; } }




     //   public abstract void inputinfo()
      //  {

      //  }

    }
}
