﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Inventory_Items
    {
        protected string InventroryItem;
        public string inventoryItem
        { set { InventroryItem = value; } get { return InventroryItem; } }

        protected int InventoryID;
        public int inventoryID
        { set { InventoryID = value; } get { return InventoryID; } }

        public void UpdateInvent()
        {

        }
    }
}
