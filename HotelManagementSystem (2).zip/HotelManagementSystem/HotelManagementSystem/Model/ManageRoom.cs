﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class ManageRoom
    {
        protected int RoomNo;
        public int room_no
        { set { RoomNo = value; } get { return RoomNo; } }

        protected int RoomType;
        public int roomType
        { set { RoomType = value; } get { return RoomType; } }

        protected int Price;
        public int price
        { set { Price = value; } get { return Price; } }

        public string avali;
    }
}
