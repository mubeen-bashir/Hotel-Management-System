﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Manager
    {
        protected int Languages;
        public int languages
        { set { Languages = value; } get { return Languages; } }

        public void Purchaseinventory()
        {

        }
        public void ManageInvent()
        {

        }

        public void ManageStaff()
        {

        }

        public void CustomerHandling()
        {

        }
    }
}
