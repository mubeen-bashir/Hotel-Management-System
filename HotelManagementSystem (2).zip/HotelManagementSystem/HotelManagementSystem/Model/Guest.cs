﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Guest:Human
    {
        protected int Room_no;
        public int room_no
        { set { Room_no = value; } get { return Room_no; } }

        protected int Room_type;
        public int room_type
        { set { Room_type = value; } get { return Room_type; } }

        protected int Luggage;
        public int luggage
        { set { Luggage = value; } get { return Luggage; } }

        protected int Payment;
        public int payment
        { set { Payment = value; } get { return Payment; } }

        protected int Duration;
        public int duration
        { set { Duration = value; } get { return Duration; } }
        public void input_customer()
        {

        }
    }
}
