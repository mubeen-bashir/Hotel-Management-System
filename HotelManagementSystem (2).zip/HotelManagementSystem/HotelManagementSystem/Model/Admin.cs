﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Admin
    {
        protected int Username;
        public int username
        { set { Username = value; } get { return Username; } }

        protected int Admin_Password;
        public int admin_Password
        { set { Admin_Password = value; } get { return Admin_Password; } }

        public void login()
        {

        }
        public void logout()
        {

        }
    }
}
