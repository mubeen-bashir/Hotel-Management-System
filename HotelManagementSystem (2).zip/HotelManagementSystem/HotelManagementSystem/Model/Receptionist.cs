﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Receptionist
    {
        protected int Recep_Password;
        public int recep_Password
        { set { Recep_Password = value; } get { return Recep_Password; } }

        protected int Username;
        public int username
        { set { Username = value; } get { return Username; } }
        public void login()
        {

        }
        public void logout()
        {

        }
        public void CheckAvailability()
        {

        }
        public void cal_payment()
        {

        }
    }
}
