﻿namespace HotelManagementSystem
{
    partial class ManageReceptionist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lable1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxGender = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxAge = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.GClearFields = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.GRemove = new System.Windows.Forms.Button();
            this.GEdit = new System.Windows.Forms.Button();
            this.GAddNew = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBoxGAddress = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxGName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxGCNIC = new System.Windows.Forms.TextBox();
            this.textBoxGPhone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxGId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.lable1.Location = new System.Drawing.Point(369, 21);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(315, 37);
            this.lable1.TabIndex = 0;
            this.lable1.Text = "Manage Receptionist";
            this.lable1.UseWaitCursor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(93, 219);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 22);
            this.label9.TabIndex = 23;
            this.label9.Text = "Email:";
            this.label9.UseWaitCursor = true;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(169, 209);
            this.textBoxEmail.Multiline = true;
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(274, 32);
            this.textBoxEmail.TabIndex = 22;
            this.textBoxEmail.UseWaitCursor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(88, 258);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 22);
            this.label8.TabIndex = 21;
            this.label8.Text = "Gender:";
            this.label8.UseWaitCursor = true;
            // 
            // comboBoxGender
            // 
            this.comboBoxGender.FormattingEnabled = true;
            this.comboBoxGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxGender.Location = new System.Drawing.Point(170, 247);
            this.comboBoxGender.Name = "comboBoxGender";
            this.comboBoxGender.Size = new System.Drawing.Size(83, 39);
            this.comboBoxGender.TabIndex = 20;
            this.comboBoxGender.UseWaitCursor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(342, 258);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 22);
            this.label4.TabIndex = 19;
            this.label4.Text = "Age:";
            this.label4.UseWaitCursor = true;
            // 
            // textBoxAge
            // 
            this.textBoxAge.Location = new System.Drawing.Point(389, 247);
            this.textBoxAge.Multiline = true;
            this.textBoxAge.Name = "textBoxAge";
            this.textBoxAge.Size = new System.Drawing.Size(54, 39);
            this.textBoxAge.TabIndex = 18;
            this.textBoxAge.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(93, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 22);
            this.label1.TabIndex = 17;
            this.label1.Text = "CNIC:";
            this.label1.UseWaitCursor = true;
            // 
            // GClearFields
            // 
            this.GClearFields.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GClearFields.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.GClearFields.Location = new System.Drawing.Point(102, 429);
            this.GClearFields.Name = "GClearFields";
            this.GClearFields.Size = new System.Drawing.Size(257, 43);
            this.GClearFields.TabIndex = 16;
            this.GClearFields.Text = "Clear Fields";
            this.GClearFields.UseVisualStyleBackColor = true;
            this.GClearFields.UseWaitCursor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(519, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 22);
            this.label7.TabIndex = 15;
            this.label7.Text = "Records View:";
            this.label7.UseWaitCursor = true;
            // 
            // GRemove
            // 
            this.GRemove.BackColor = System.Drawing.Color.Salmon;
            this.GRemove.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GRemove.Location = new System.Drawing.Point(308, 371);
            this.GRemove.Name = "GRemove";
            this.GRemove.Size = new System.Drawing.Size(119, 43);
            this.GRemove.TabIndex = 14;
            this.GRemove.Text = "Remove";
            this.GRemove.UseVisualStyleBackColor = false;
            this.GRemove.UseWaitCursor = true;
            // 
            // GEdit
            // 
            this.GEdit.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GEdit.Location = new System.Drawing.Point(169, 371);
            this.GEdit.Name = "GEdit";
            this.GEdit.Size = new System.Drawing.Size(119, 43);
            this.GEdit.TabIndex = 13;
            this.GEdit.Text = "Edit";
            this.GEdit.UseVisualStyleBackColor = true;
            this.GEdit.UseWaitCursor = true;
            // 
            // GAddNew
            // 
            this.GAddNew.BackColor = System.Drawing.Color.PowderBlue;
            this.GAddNew.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GAddNew.Location = new System.Drawing.Point(12, 371);
            this.GAddNew.Name = "GAddNew";
            this.GAddNew.Size = new System.Drawing.Size(147, 43);
            this.GAddNew.TabIndex = 12;
            this.GAddNew.Text = "Add New";
            this.GAddNew.UseVisualStyleBackColor = false;
            this.GAddNew.UseWaitCursor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(523, 124);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(454, 337);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.UseWaitCursor = true;
            // 
            // textBoxGAddress
            // 
            this.textBoxGAddress.Location = new System.Drawing.Point(169, 330);
            this.textBoxGAddress.Multiline = true;
            this.textBoxGAddress.Name = "textBoxGAddress";
            this.textBoxGAddress.Size = new System.Drawing.Size(274, 32);
            this.textBoxGAddress.TabIndex = 5;
            this.textBoxGAddress.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(83, 335);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 22);
            this.label6.TabIndex = 5;
            this.label6.Text = "Address:";
            this.label6.UseWaitCursor = true;
            // 
            // textBoxGName
            // 
            this.textBoxGName.Location = new System.Drawing.Point(169, 129);
            this.textBoxGName.Multiline = true;
            this.textBoxGName.Name = "textBoxGName";
            this.textBoxGName.Size = new System.Drawing.Size(274, 32);
            this.textBoxGName.TabIndex = 2;
            this.textBoxGName.UseWaitCursor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(93, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 22);
            this.label5.TabIndex = 0;
            this.label5.Text = "Name:";
            this.label5.UseWaitCursor = true;
            // 
            // textBoxGCNIC
            // 
            this.textBoxGCNIC.Location = new System.Drawing.Point(169, 169);
            this.textBoxGCNIC.Multiline = true;
            this.textBoxGCNIC.Name = "textBoxGCNIC";
            this.textBoxGCNIC.Size = new System.Drawing.Size(274, 32);
            this.textBoxGCNIC.TabIndex = 3;
            this.textBoxGCNIC.UseWaitCursor = true;
            // 
            // textBoxGPhone
            // 
            this.textBoxGPhone.Location = new System.Drawing.Point(169, 292);
            this.textBoxGPhone.Multiline = true;
            this.textBoxGPhone.Name = "textBoxGPhone";
            this.textBoxGPhone.Size = new System.Drawing.Size(274, 32);
            this.textBoxGPhone.TabIndex = 4;
            this.textBoxGPhone.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(94, 296);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 22);
            this.label3.TabIndex = 4;
            this.label3.Text = "Phone:";
            this.label3.UseWaitCursor = true;
            // 
            // txtBoxGId
            // 
            this.txtBoxGId.Location = new System.Drawing.Point(169, 91);
            this.txtBoxGId.Multiline = true;
            this.txtBoxGId.Name = "txtBoxGId";
            this.txtBoxGId.Size = new System.Drawing.Size(274, 32);
            this.txtBoxGId.TabIndex = 1;
            this.txtBoxGId.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(120, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "ID:";
            this.label2.UseWaitCursor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Controls.Add(this.lable1);
            this.panel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(0, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(988, 68);
            this.panel2.TabIndex = 0;
            this.panel2.UseWaitCursor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.textBoxEmail);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.comboBoxGender);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBoxAge);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.GClearFields);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.GRemove);
            this.panel1.Controls.Add(this.GEdit);
            this.panel1.Controls.Add(this.GAddNew);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.textBoxGAddress);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.textBoxGName);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textBoxGCNIC);
            this.panel1.Controls.Add(this.textBoxGPhone);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtBoxGId);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Font = new System.Drawing.Font("Calisto MT", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(20, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(989, 481);
            this.panel1.TabIndex = 1;
            this.panel1.UseWaitCursor = true;
            // 
            // ManageReceptionist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 477);
            this.Controls.Add(this.panel1);
            this.Name = "ManageReceptionist";
            this.Text = "ManageReceptionist";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxGender;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxAge;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button GClearFields;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button GRemove;
        private System.Windows.Forms.Button GEdit;
        private System.Windows.Forms.Button GAddNew;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBoxGAddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxGName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxGCNIC;
        private System.Windows.Forms.TextBox textBoxGPhone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxGId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
    }
}