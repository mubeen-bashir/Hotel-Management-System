﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagementSystem
{
    class Reservation
    {
        public int resid;
        public string guestid1;
        public string roomtype;
        public string roomno;
        public DateTime datein;
        public DateTime dateout;
    }
}
