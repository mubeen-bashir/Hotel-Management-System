﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace HotelManagementSystem
{
    public partial class ManageManager : Form
    {
        Human h = new Human();
        public ManageManager()
        {
            InitializeComponent();
        }

        private void GAddNew_Click(object sender, EventArgs e)
        {  string dbconn = Customer.dbcon();
        MySqlConnection con = new MySqlConnection(dbconn);
            string query = "insert into hms.manager(id2,name,cnic,email,gender,age,phone,address) VALUES('" + h.hid + "','" + h.name + "','" + h.cnic + "','" + h.email + "','" + h.gender + "','" + h.age + "','" + h.phone + "','" + h.address + "');";
            con.Open();
            MySqlCommand comm = new MySqlCommand(query, con);
            if (comm.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Data Inserted");
            }
            else
            {
                MessageBox.Show("Not Inserted");
            }
            con.Close();
        }

        private void txtBoxGId_TextChanged(object sender, EventArgs e)
        {
            h.hid = textBoxmid.Text;
        }

        private void textBoxmName_TextChanged(object sender, EventArgs e)
        {
            h.name = textBoxmName.Text;
        }

        private void textBoxmCNIC_TextChanged(object sender, EventArgs e)
        {
            h.cnic = textBoxmCNIC.Text;
        }

        private void textBoxmEmail_TextChanged(object sender, EventArgs e)
        {
            h.email = textBoxmEmail.Text;
        }

        private void comboBoxmGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            h.gender = comboBoxmGender.Text;
        }

        private void textBoxmAge_TextChanged(object sender, EventArgs e)
        {
            h.age = int.Parse(textBoxmAge.Text);
        }

        private void textBoxmPhone_TextChanged(object sender, EventArgs e)
        {
            h.phone = textBoxmPhone.Text;
        }

        private void textBoxmAddress_TextChanged(object sender, EventArgs e)
        {
            h.address = textBoxmAddress.Text;
        }
    }
}
